BOLLEN STAPELEN AUTO PLAYER — EXPERIMENTEEL PROTOTYPE

Wat dit project bevat
- Een Android-appscherm met een knop naar de toegankelijkheidsinstellingen.
- Een AccessibilityService die op Android 11+ screenshots probeert te lezen.
- Een eenvoudige kleurherkenner voor de oranje/rode bol.
- Een experimentele voorspelling van het moment waarop de bol het midden passeert.
- Een automatische tik via Android dispatchGesture.

BELANGRIJK
Dit is broncode, geen kant-en-klare APK. Het project is niet hier gecompileerd of getest op een echte S24.
De herkenning is een eerste prototype en is NIET gegarandeerd perfect. De spelbeelden kunnen variëren
door resolutie, animatie, reclame, vertraging of kleurveranderingen. Stop de service als hij verkeerd tikt.

Bouwen
1. Open deze map in Android Studio op een computer.
2. Laat Gradle synchroniseren.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Installeer de APK op je Samsung S24.
5. Open de app en schakel de toegankelijkheidsservice in via de knop.

Test eerst met korte sessies. Android toont een duidelijke systeemwaarschuwing wanneer je een
toegankelijkheidsservice inschakelt. Schakel hem weer uit via Instellingen > Toegankelijkheid
wanneer je hem niet gebruikt.

Waarom dit nog niet perfect is
De huidige detector gebruikt kleur en een vaste middenpositie uit de aangeleverde opname.
Voor een veel betrouwbaardere versie moeten we meerdere echte spelrondes meten, de bol als
afzonderlijk object volgen, de werkelijke landingszone herkennen en timing kalibreren.

BOUWEN ZONDER EIGEN COMPUTER (via GitHub Actions)
1. Maak op GitHub een nieuwe lege repository.
2. Upload alle bestanden en mappen uit dit ZIP-bestand naar de repository.
3. Open het tabblad Actions en kies 'Build Android APK'.
4. Druk op 'Run workflow' (of wacht tot de push-build klaar is).
5. Open de geslaagde workflow en download onder Artifacts het bestand
   bollen-auto-player-debug.
6. Pak het artifact uit; daarin staat app-debug.apk.
7. Download de APK op je S24 en installeer hem. Android kan vragen om
   installatie vanuit die browser/bestandsapp toe te staan.

Let op: dit cloud-buildpad is toegevoegd maar niet uitgevoerd of geverifieerd.


CRASHFIX
Deze versie houdt de screenshot-buffer open totdat de afbeelding is gekopieerd en voert beeldanalyse uit op de hoofdthread. De eerdere versie sloot de buffer te vroeg; dat kon een crash veroorzaken. De detectie en timing blijven experimenteel en moeten nog op het toestel getest worden.
