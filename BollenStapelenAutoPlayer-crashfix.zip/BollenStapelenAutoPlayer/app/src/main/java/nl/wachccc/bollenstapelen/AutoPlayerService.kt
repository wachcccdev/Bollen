package nl.wachccc.bollenstapelen

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Prototype for the supplied Bollen stapelen screen recording.
 * It samples the upper-middle play area, looks for the orange/red ball,
 * estimates its horizontal movement and taps when it is predicted to cross
 * the screen's horizontal centre (where the stack appears in the recording).
 *
 * This is deliberately conservative: it does not tap if detection is uncertain.
 */
class AutoPlayerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var running = false
    private var lastX = Float.NaN
    private var lastTime = 0L
    private var lastTap = 0L
    private var lastBallY = Float.NaN
    private var tappedThisBall = false

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            if (Build.VERSION.SDK_INT >= 30) {
                takeScreenshot(Display.DEFAULT_DISPLAY, executor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(result: ScreenshotResult) {
                            val hardware = result.hardwareBuffer
                            var copy: Bitmap? = null
                            try {
                                // Keep the hardware buffer open until the software copy is complete.
                                val hardwareBitmap = Bitmap.wrapHardwareBuffer(hardware, result.colorSpace)
                                if (hardwareBitmap != null) {
                                    copy = hardwareBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                    hardwareBitmap.recycle()
                                }
                            } catch (_: Exception) {
                                // A frame may be unavailable while Android changes screens.
                            } finally {
                                hardware.close()
                            }
                            if (copy != null) {
                                handler.post {
                                    if (running) analyze(copy!!)
                                    copy!!.recycle()
                                }
                            }
                        }
                        override fun onFailure(errorCode: Int) {
                            // No screenshot this cycle; retry next cycle.
                        }
                    })
            }
            handler.postDelayed(this, 70L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(loop)
        executor.shutdown()
        super.onDestroy()
    }

    private fun analyze(bmp: Bitmap) {
        val w = bmp.width
        val h = bmp.height
        if (w < 200 || h < 400) return

        // In the supplied recording, the moving ball is in the upper/middle
        // play field; the stack and score are outside this detection region.
        val y0 = (h * 0.25f).toInt()
        val y1 = (h * 0.66f).toInt()
        val x0 = (w * 0.08f).toInt()
        val x1 = (w * 0.92f).toInt()

        var count = 0
        var sumX = 0.0
        var sumY = 0.0
        var minX = w
        var maxX = 0
        var minY = h
        var maxY = 0

        // Subsample pixels for speed. Orange ball pixels are saturated red/orange.
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val c = bmp.getPixel(x, y)
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                if (r > 165 && g in 35..155 && b < 90 && r > g * 1.35) {
                    count++
                    sumX += x
                    sumY += y
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
                x += 3
            }
            y += 3
        }

        // Reject tiny specks and very broad orange areas.
        val boxW = maxX - minX
        val boxH = maxY - minY
        if (count < 35 || boxW < w * 0.035f || boxW > w * 0.25f ||
            boxH < h * 0.015f || boxH > h * 0.12f) {
            return
        }

        val cx = (sumX / count).toFloat()
        val cy = (sumY / count).toFloat()
        val now = System.currentTimeMillis()

        // A newly spawned ball can be distinguished by a meaningful vertical reset.
        if (!lastBallY.isNaN() && abs(cy - lastBallY) > h * 0.07f) {
            tappedThisBall = false
        }
        lastBallY = cy

        if (!lastX.isNaN() && lastTime > 0L && !tappedThisBall) {
            val dt = (now - lastTime).coerceAtLeast(1L).toFloat()
            val vx = (cx - lastX) / dt // pixels per millisecond
            val targetX = w / 2f
            if (abs(vx) > 0.08f) {
                val timeToCentre = (targetX - cx) / vx
                // Tap slightly before the predicted centre crossing to allow for latency.
                if (timeToCentre in 25f..130f && now - lastTap > 450L) {
                    tap(w / 2f, h * 0.52f)
                    lastTap = now
                    tappedThisBall = true
                }
            } else if (abs(cx - targetX) < w * 0.012f && now - lastTap > 450L) {
                tap(w / 2f, h * 0.52f)
                lastTap = now
                tappedThisBall = true
            }
        }

        lastX = cx
        lastTime = now
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 45L))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
