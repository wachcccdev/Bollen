package nl.wachccc.bollenstapelen

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * V4 prototype for the supplied Bollen stapelen recording.
 * The game instruction says to tap the visible ball to drop it. The previous
 * version waited for horizontal velocity and only recognized red/orange balls.
 * This version detects orange/red, cyan/blue, white and dark-purple balls,
 * tracks a stable candidate in the play area, and taps the ball itself when it
 * is close to the stack's observed horizontal lane.
 */
class AutoPlayerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var running = false
    private var lastTap = 0L
    private var lostFrames = 0
    private var stableFrames = 0
    private var tappedThisBall = false
    private var lastCandidateX = Float.NaN
    private var lastCandidateY = Float.NaN

    private data class Ball(val cx: Float, val cy: Float, val width: Int, val height: Int, val pixels: Int)

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            if (Build.VERSION.SDK_INT >= 30) {
                takeScreenshot(Display.DEFAULT_DISPLAY, executor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val hardware = result.hardwareBuffer
                        var copy: Bitmap? = null
                        try {
                            val wrapped = Bitmap.wrapHardwareBuffer(hardware, result.colorSpace)
                            if (wrapped != null) {
                                copy = wrapped.copy(Bitmap.Config.ARGB_8888, false)
                                wrapped.recycle()
                            }
                        } catch (_: Exception) {
                        } finally {
                            hardware.close()
                        }
                        if (copy != null) {
                            val frame = copy
                            handler.post {
                                if (running) analyze(frame!!)
                                frame!!.recycle()
                            }
                        }
                    }
                    override fun onFailure(errorCode: Int) {}
                })
            }
            handler.postDelayed(this, 85L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(loop)
        executor.shutdown()
        super.onDestroy()
    }

    private fun isBallPixel(color: Int, hsv: FloatArray): Boolean {
        Color.colorToHSV(color, hsv)
        val hue = hsv[0]
        val sat = hsv[1]
        val value = hsv[2]
        val warm = (hue <= 52f || hue >= 342f) && sat >= 0.34f && value >= 0.28f
        val cyanBlue = hue in 150f..235f && sat >= 0.30f && value >= 0.25f
        val pale = sat <= 0.23f && value >= 0.68f
        val purple = hue in 255f..315f && sat >= 0.58f && value in 0.20f..0.58f
        return warm || cyanBlue || pale || purple
    }

    private fun analyze(bitmap: Bitmap) {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 300 || h < 700) return

        // Build a low-resolution colour mask. The game balls are strongly coloured
        // (orange/red, cyan/blue, pale/white or dark purple) while the sky is mostly
        // a smooth gradient. A circular local-density score separates the ball from it.
        val step = 4
        val x0 = (w * 0.10f).toInt()
        val x1 = (w * 0.90f).toInt()
        val y0 = (h * 0.40f).toInt()
        val y1 = (h * 0.74f).toInt()
        val cols = ((x1 - x0) + step - 1) / step
        val rows = ((y1 - y0) + step - 1) / step
        val integral = IntArray((cols + 1) * (rows + 1))
        val hsvScratch = FloatArray(3)

        for (gy in 0 until rows) {
            var rowCount = 0
            val py = (y0 + gy * step).coerceAtMost(h - 1)
            for (gx in 0 until cols) {
                val px = (x0 + gx * step).coerceAtMost(w - 1)
                if (isBallPixel(bitmap.getPixel(px, py), hsvScratch)) rowCount++
                val at = (gy + 1) * (cols + 1) + (gx + 1)
                integral[at] = integral[gy * (cols + 1) + (gx + 1)] + rowCount
            }
        }

        fun rectSum(left: Int, top: Int, right: Int, bottom: Int): Int {
            val l = left.coerceIn(0, cols)
            val t = top.coerceIn(0, rows)
            val r = right.coerceIn(0, cols)
            val b = bottom.coerceIn(0, rows)
            if (r <= l || b <= t) return 0
            val stride = cols + 1
            return integral[b * stride + r] - integral[t * stride + r] -
                integral[b * stride + l] + integral[t * stride + l]
        }

        // A ball is about 140–190 px across in the supplied 1080 px recording.
        val inner = (w * 0.045f / step).toInt().coerceAtLeast(8)
        val outer = (w * 0.085f / step).toInt().coerceAtLeast(inner + 4)
        var bestScore = 0f
        var bestX = Float.NaN
        var bestY = Float.NaN

        val gxStart = ((w * 0.18f - x0) / step).toInt().coerceAtLeast(outer)
        val gxEnd = ((w * 0.84f - x0) / step).toInt().coerceAtMost(cols - outer)
        val gyStart = ((h * 0.43f - y0) / step).toInt().coerceAtLeast(outer)
        val gyEnd = ((h * 0.72f - y0) / step).toInt().coerceAtMost(rows - outer)

        var gy = gyStart
        while (gy <= gyEnd) {
            var gx = gxStart
            while (gx <= gxEnd) {
                val innerCount = rectSum(gx - inner, gy - inner, gx + inner + 1, gy + inner + 1)
                val outerCount = rectSum(gx - outer, gy - outer, gx + outer + 1, gy + outer + 1)
                val innerArea = (inner * 2 + 1) * (inner * 2 + 1)
                val outerArea = (outer * 2 + 1) * (outer * 2 + 1)
                val ringArea = outerArea - innerArea
                val innerDensity = innerCount.toFloat() / innerArea
                val ringDensity = (outerCount - innerCount).coerceAtLeast(0).toFloat() / ringArea
                val score = innerDensity - ringDensity * 0.55f
                if (innerDensity >= 0.58f && ringDensity <= 0.72f && score > bestScore) {
                    bestScore = score
                    bestX = x0 + gx * step.toFloat()
                    bestY = y0 + gy * step.toFloat()
                }
                gx += 3
            }
            gy += 3
        }

        if (bestX.isNaN()) {
            lostFrames++
            if (lostFrames >= 4) resetTracking()
            return
        }

        lostFrames = 0
        val now = System.currentTimeMillis()
        if (!lastCandidateX.isNaN()) {
            val moved = abs(bestX - lastCandidateX)
            val movedY = abs(bestY - lastCandidateY)
            if (moved > w * 0.10f || movedY > h * 0.08f) {
                stableFrames = 0
                // A clearly different position after the previous ball disappeared is a new ball.
                if (tappedThisBall && moved > w * 0.14f) tappedThisBall = false
            }
        }

        if (tappedThisBall) {
            lastCandidateX = bestX
            lastCandidateY = bestY
            return
        }

        stableFrames++
        lastCandidateX = bestX
        lastCandidateY = bestY

        // The cone/stack lane is slightly right of screen centre in the supplied recording.
        // The game instruction is to tap the ball itself to release it.
        val stackLaneX = w * 0.60f
        val aligned = abs(bestX - stackLaneX) <= w * 0.09f
        if (stableFrames >= 4 && aligned && now - lastTap > 650L) {
            tap(bestX, bestY)
            lastTap = now
            tappedThisBall = true
        }
    }

    private fun resetTracking() {
        stableFrames = 0
        tappedThisBall = false
        lastCandidateX = Float.NaN
        lastCandidateY = Float.NaN
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 55L))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
