package nl.wachccc.bollenstapelen

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Bollen Auto Player — prototype"
            textSize = 22f
            setPadding(24, 32, 24, 12)
        }
        val info = TextView(this).apply {
            text = "1. Open Toegankelijkheid en schakel Bollen Auto Player in.\n\n" +
                "2. Open daarna Bollen stapelen.\n\n" +
                "3. De herkenning en automatische tikfunctie zijn experimenteel; test eerst kort."
            textSize = 16f
            setPadding(24, 12, 24, 24)
        }
        val settings = Button(this).apply {
            text = "Open toegankelijkheidsinstellingen"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            addView(title)
            addView(info)
            addView(settings)
        }
        setContentView(layout)
    }
}
