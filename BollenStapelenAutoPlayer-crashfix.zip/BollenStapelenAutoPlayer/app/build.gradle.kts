plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "nl.wachccc.bollenstapelen"
    compileSdk = 35
    defaultConfig {
        applicationId = "nl.wachccc.bollenstapelen"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
