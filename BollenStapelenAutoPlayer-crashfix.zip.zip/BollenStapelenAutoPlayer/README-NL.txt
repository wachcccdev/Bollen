Bollen Auto Player V6 — Leermodus (experimenteel)

NIEUW: HANDMATIG AANLEREN
- Start eerst het spel.
- Open Bollen Auto Player via Recente apps.
- Kies "Leer een bolkleur". De app gaat terug naar het spel en toont een transparante selectie-overlay.
- Tik precies in het midden van de bol. De voorbeeldkleur wordt lokaal op het toestel bewaard.
- Herhaal dit voor verschillende bolkleuren door Bollen Auto Player opnieuw via Recente apps te openen.
- Kies eventueel "Leer achtergrondkleur" en tik op een representatief stuk achtergrond.
- Kies "Start automatische speler". De app gaat terug naar het spel; tik op het spel om de automatische modus te activeren.
- Gebruik "Pauzeer automatische speler" om te stoppen.
- "Wis alle aangeleerde voorbeelden" verwijdert de lokaal opgeslagen voorbeeldkleuren.

HOE HET LEREN WERKT
De app bewaart RGB-voorbeelden van bollen en achtergrondkleuren in lokale SharedPreferences.
De beeldherkenning combineert overeenkomst met de aangeleerde bolkleuren met het verschil
in kleur tussen het midden van een kandidaat en de omliggende ring. Aangeleerde achtergrond-
kleuren worden als negatieve voorbeelden gebruikt. Er is geen cloudverbinding en er wordt
geen afbeelding naar een server verstuurd.

BEPERKINGEN
Dit is eenvoudige lokale voorbeeldgestuurde kalibratie, geen getraind neuraal netwerk.
Het leert vooral kleurvoorbeelden; vorm en positie blijven vaste heuristieken. Een bol die
exact dezelfde kleur en textuur heeft als de achtergrond kan nog steeds gemist worden.
De automatische tikfunctie blijft experimenteel. Controleer de werking en pauzeer direct
als de app op verkeerde plekken tikt. De toegankelijkheidsservice kan schermbeelden lezen
en aanrakingen uitvoeren; schakel die uit wanneer je de app niet gebruikt.
