Bollen Auto Player V4 — experimentele versie

Wat is aangepast:
- De oude detector herkende alleen rood/oranje. V4 detecteert ook lichte/witte,
  cyan/blauwe en donkerpaarse ballen.
- De oude code wachtte op horizontale snelheid, terwijl de video de instructie
  toont: "Tik om de bol te laten vallen". V4 wacht op een stabiele baldetectie.
- De tik wordt op de gevonden bal zelf uitgevoerd, niet op een vaste schermpositie.
- De detector zoekt alleen in het speelgebied boven de stapel en gebruikt
  grootte/vorm om achtergrondvlakken uit te sluiten.
- V4 tikt alleen wanneer de bal dicht bij de stapellijn staat. In de meegeleverde
  opname ligt de stapel ongeveer op 60% van de schermbreedte.

LET OP:
Dit is een experimentele beeldherkenningsbot, geen gegarandeerd perfecte speler.
De spelinterface, schermuitsnede en bolkleuren kunnen variëren. Test eerst kort.
De toegankelijkheidsservice kan schermbeelden lezen en aanrakingen uitvoeren;
zet hem uit wanneer je de app niet gebruikt.


V5 — KLEURONAFHANKELIJKE DETECTIE
De bolherkenning gebruikt nu het kleurverschil tussen het midden van een
kandidaat en de omliggende ring. Er is dus geen vaste lijst met toegestane
bolkleuren meer. De detectie zoekt in het speelgebied en de richtlijn voor de
stapel is bijgesteld naar het midden van de beker in de aangeleverde opname.
Dit blijft experimentele beeldherkenning: achtergronddelen met sterk contrast
kunnen nog foutief worden gekozen. Test eerst kort en controleer de tikken.
