package nl.wachccc.bollenstapelen

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ball_trainer", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = TextView(this).apply {
            text = "Bollen Auto Player V6 — Leermodus"
            textSize = 23f
            setPadding(8, 16, 8, 12)
        }
        val info = TextView(this).apply {
            text = "Train de herkenning met voorbeelden uit jouw spel. Schakel eerst de toegankelijkheidsservice in. Start eerst het spel. Open daarna deze app via Recente apps. Kies een trainingsknop: de app gaat terug naar het spel en toont een transparant selectiescherm. Tik één keer precies op het midden van een bol of op de achtergrond. Herhaal dit door de app opnieuw via Recente apps te openen voor extra voorbeelden. Kies daarna Start automatische speler; tik op het spel om de bot te activeren. De app bewaart voorbeelden alleen op dit toestel."
            textSize = 15f
            setPadding(8, 4, 8, 16)
        }
        val status = TextView(this).apply {
            textSize = 14f
            setPadding(8, 8, 8, 12)
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action(); status.text = trainingStatus() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
            addView(title); addView(info)
            addView(button("1. Leer een bolkleur (tik op een bol)") { setMode("sample_ball"); moveTaskToBack(true) })
            addView(button("2. Leer achtergrondkleur (tik op achtergrond)") { setMode("sample_background"); moveTaskToBack(true) })
            addView(button("3. Start automatische speler") { setMode("start_auto"); moveTaskToBack(true) })
            addView(button("Pauzeer automatische speler") { setMode("paused") })
            addView(button("Wis alle aangeleerde voorbeelden") {
                prefs.edit().remove("ball_samples").remove("background_samples").putString("mode", "auto").apply()
            })
            addView(button("Open toegankelijkheidsinstellingen") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
            addView(status)
        }
        setContentView(layout)
        status.text = trainingStatus()
    }

    private fun setMode(mode: String) {
        prefs.edit().putString("mode", mode).apply()
    }

    private fun trainingStatus(): String {
        val balls = (prefs.getString("ball_samples", "") ?: "").split(';').count { it.isNotBlank() }
        val backgrounds = (prefs.getString("background_samples", "") ?: "").split(';').count { it.isNotBlank() }
        val mode = prefs.getString("mode", "paused") ?: "paused"
        return "\nOpgeslagen voorbeelden: $balls bolkleur(en), $backgrounds achtergrondkleur(en).\nModus: $mode\n\nTip: leer meerdere verschillende bolkleuren en minstens één achtergrondkleur aan."
    }
}
