package nl.wachccc.bollenstapelen

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Prototype for the supplied Bollen stapelen screen recording.
 * It separates red/orange blobs, ignores the lower stack, and tracks the moving ball,
 * estimates its horizontal movement and taps when it is predicted to cross
 * the screen's horizontal centre (where the stack appears in the recording).
 *
 * This is deliberately conservative: it does not tap if detection is uncertain.
 */
class AutoPlayerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var running = false
    private var lastX = Float.NaN
    private var lastTime = 0L
    private var lastTap = 0L
    private var lastBallY = Float.NaN
    private var tappedThisBall = false
    private var lostFrames = 0
    private var stableFrames = 0
    private var smoothedVelocity = 0f
    private var previousDirection = 0

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            if (Build.VERSION.SDK_INT >= 30) {
                takeScreenshot(Display.DEFAULT_DISPLAY, executor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(result: ScreenshotResult) {
                            val hardware = result.hardwareBuffer
                            var copy: Bitmap? = null
                            try {
                                // Keep the hardware buffer open until the software copy is complete.
                                val hardwareBitmap = Bitmap.wrapHardwareBuffer(hardware, result.colorSpace)
                                if (hardwareBitmap != null) {
                                    copy = hardwareBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                    hardwareBitmap.recycle()
                                }
                            } catch (_: Exception) {
                                // A frame may be unavailable while Android changes screens.
                            } finally {
                                hardware.close()
                            }
                            if (copy != null) {
                                handler.post {
                                    if (running) analyze(copy!!)
                                    copy!!.recycle()
                                }
                            }
                        }
                        override fun onFailure(errorCode: Int) {
                            // No screenshot this cycle; retry next cycle.
                        }
                    })
            }
            handler.postDelayed(this, 70L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(loop)
        executor.shutdown()
        super.onDestroy()
    }

    private fun analyze(bmp: Bitmap) {
        val w = bmp.width
        val h = bmp.height
        if (w < 200 || h < 400) return

        // Detect separate red/orange objects instead of averaging every red pixel.
        // The stacked balls at the bottom otherwise merge with the moving ball
        // and make the old detector reject the whole frame.
        val y0 = (h * 0.18f).toInt()
        val y1 = (h * 0.76f).toInt()
        val x0 = (w * 0.06f).toInt()
        val x1 = (w * 0.94f).toInt()
        val step = 3
        val cols = ((x1 - x0) + step - 1) / step
        val rows = ((y1 - y0) + step - 1) / step
        val mask = BooleanArray(cols * rows)

        var gy = 0
        while (gy < rows) {
            var gx = 0
            while (gx < cols) {
                val c = bmp.getPixel(x0 + gx * step, y0 + gy * step)
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                mask[gy * cols + gx] =
                    r > 165 && g in 35..155 && b < 105 && r > g * 1.30
                gx++
            }
            gy++
        }

        data class Blob(val count: Int, val cx: Float, val cy: Float,
                        val width: Int, val height: Int)

        val visited = BooleanArray(mask.size)
        val queue = IntArray(mask.size)
        val blobs = ArrayList<Blob>()

        for (index in mask.indices) {
            if (!mask[index] || visited[index]) continue
            var head = 0
            var tail = 0
            queue[tail++] = index
            visited[index] = true
            var count = 0
            var sumX = 0.0
            var sumY = 0.0
            var minX = cols
            var maxX = 0
            var minY = rows
            var maxY = 0

            while (head < tail) {
                val p = queue[head++]
                val px = p % cols
                val py = p / cols
                count++
                sumX += x0 + px * step
                sumY += y0 + py * step
                if (px < minX) minX = px
                if (px > maxX) maxX = px
                if (py < minY) minY = py
                if (py > maxY) maxY = py

                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = px + dx
                    val ny = py + dy
                    if (nx !in 0 until cols || ny !in 0 until rows) continue
                    val ni = ny * cols + nx
                    if (mask[ni] && !visited[ni]) {
                        visited[ni] = true
                        queue[tail++] = ni
                    }
                }
            }

            val bw = (maxX - minX + 1) * step
            val bh = (maxY - minY + 1) * step
            if (count >= 28 && bw >= w * 0.045f && bw <= w * 0.27f &&
                bh >= h * 0.018f && bh <= h * 0.13f) {
                blobs.add(Blob(count, (sumX / count).toFloat(),
                    (sumY / count).toFloat(), bw, bh))
            }
        }

        // Prefer the uppermost isolated ball; the lower connected stack is ignored.
        val candidate = blobs
            .filter { it.cy < h * 0.70f }
            .minByOrNull { it.cy }

        if (candidate == null) {
            onBallNotFound()
            return
        }

        val cx = candidate.cx
        val cy = candidate.cy
        val now = System.currentTimeMillis()

        // A short detection gap usually means the previous ball has landed
        // and a new one is about to appear. Reset after several missed frames,
        // rather than relying only on a vertical-position change.
        if (lostFrames >= 3) {
            lastX = Float.NaN
            lastTime = 0L
            tappedThisBall = false
            stableFrames = 0
            smoothedVelocity = 0f
            previousDirection = 0
        }
        lostFrames = 0

        // Also detect a newly spawned ball when it appears far from the old track.
        if (!lastX.isNaN() && abs(cx - lastX) > w * 0.30f) {
            tappedThisBall = false
            stableFrames = 0
            smoothedVelocity = 0f
            lastTime = 0L
        }

        if (!lastX.isNaN() && lastTime > 0L && !tappedThisBall) {
            val dt = (now - lastTime).coerceIn(25L, 250L).toFloat()
            val instantVx = (cx - lastX) / dt
            // Smooth noisy frame-to-frame movement before predicting the crossing.
            smoothedVelocity = if (stableFrames == 0) instantVx
                else 0.65f * smoothedVelocity + 0.35f * instantVx

            val direction = when {
                smoothedVelocity > 0.035f -> 1
                smoothedVelocity < -0.035f -> -1
                else -> 0
            }
            if (direction != 0 && previousDirection != 0 && direction != previousDirection) {
                // A direction reversal is a new movement phase; require fresh tracking.
                stableFrames = 0
            }
            if (direction != 0) previousDirection = direction
            stableFrames++

            val targetX = w / 2f
            if (abs(smoothedVelocity) > 0.035f && stableFrames >= 2) {
                val timeToCentre = (targetX - cx) / smoothedVelocity
                // Tap only when the tracked ball is approaching the target
                // and the predicted crossing is close enough to compensate for latency.
                if (timeToCentre in 35f..180f && now - lastTap > 350L) {
                    tap(w / 2f, h * 0.52f)
                    lastTap = now
                    tappedThisBall = true
                }
            } else if (abs(cx - targetX) < w * 0.012f &&
                stableFrames >= 2 && now - lastTap > 350L) {
                tap(w / 2f, h * 0.52f)
                lastTap = now
                tappedThisBall = true
            }
        } else {
            stableFrames = 0
        }

        lastX = cx
        lastTime = now
        lastBallY = cy
    }

    private fun onBallNotFound() {
        lostFrames++
        // Do not reset on one bad frame; screenshots can be noisy.
        if (lostFrames >= 3) {
            lastX = Float.NaN
            lastTime = 0L
            tappedThisBall = false
            stableFrames = 0
            smoothedVelocity = 0f
            previousDirection = 0
        }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 45L))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
