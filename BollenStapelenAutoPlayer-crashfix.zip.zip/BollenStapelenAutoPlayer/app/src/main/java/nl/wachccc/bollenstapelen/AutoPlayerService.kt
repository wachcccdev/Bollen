package nl.wachccc.bollenstapelen

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * V6: user-guided visual calibration. The user can tap the centre of one or
 * more example balls and optionally tap background examples. Samples are kept
 * locally in SharedPreferences and used as a colour prior alongside local
 * centre-vs-ring contrast. This is a lightweight adaptive detector, not a
 * neural-network model.
 */
class AutoPlayerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var running = false
    private var lastTap = 0L
    private var lostFrames = 0
    private var stableFrames = 0
    private var tappedThisBall = false
    private var lastCandidateX = Float.NaN
    private var lastCandidateY = Float.NaN
    private var latestFrame: Bitmap? = null
    private var trainingOverlay: TrainingOverlay? = null
    private var lastMode = ""

    private val prefs by lazy { getSharedPreferences("ball_trainer", MODE_PRIVATE) }
    private data class Rgb(val r: Int, val g: Int, val b: Int)

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            handleTrainingMode()
            if (Build.VERSION.SDK_INT >= 30) {
                takeScreenshot(Display.DEFAULT_DISPLAY, executor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val hardware = result.hardwareBuffer
                        var copy: Bitmap? = null
                        try {
                            val wrapped = Bitmap.wrapHardwareBuffer(hardware, result.colorSpace)
                            if (wrapped != null) {
                                copy = wrapped.copy(Bitmap.Config.ARGB_8888, false)
                                wrapped.recycle()
                            }
                        } catch (_: Exception) {
                        } finally {
                            hardware.close()
                        }
                        if (copy != null) {
                            val frame = copy
                            handler.post {
                                if (running) analyze(frame!!)
                                frame!!.recycle()
                            }
                        }
                    }
                    override fun onFailure(errorCode: Int) {}
                })
            }
            handler.postDelayed(this, 90L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false; removeTrainingOverlay() }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(loop)
        removeTrainingOverlay()
        latestFrame?.recycle()
        latestFrame = null
        executor.shutdown()
        super.onDestroy()
    }

    private fun handleTrainingMode() {
        val mode = prefs.getString("mode", "paused") ?: "paused"
        if (mode != lastMode) {
            lastMode = mode
            when (mode) {
                "sample_ball" -> showTrainingOverlay("Tik midden op een bol")
                "sample_background" -> showTrainingOverlay("Tik op de achtergrond")
                "start_auto" -> showTrainingOverlay("Tik op het spel om te starten")
                else -> removeTrainingOverlay()
            }
        }
    }

    private fun showTrainingOverlay(message: String) {
        if (trainingOverlay != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val overlay = TrainingOverlay(message) { x, y ->
            val frame = latestFrame
            if (frame != null && x >= 0 && y >= 0 && x < frame.width && y < frame.height) {
                val mode = prefs.getString("mode", "paused") ?: "paused"
                if (mode == "start_auto") {
                    prefs.edit().putString("mode", "auto").apply()
                } else {
                    val sample = averagePatch(frame, x, y)
                    val key = if (mode == "sample_background") "background_samples" else "ball_samples"
                    val existing = prefs.getString(key, "") ?: ""
                    val encoded = "${sample.r},${sample.g},${sample.b}"
                    val updated = (existing.split(';').filter { it.isNotBlank() } + encoded).distinct().takeLast(24)
                    prefs.edit().putString(key, updated.joinToString(";")).putString("mode", "paused").apply()
                }
                lastMode = "overlay" // force next handler pass to process the new mode
                handler.post { removeTrainingOverlay() }
                resetTracking()
            } else {
                prefs.edit().putString("mode", "paused").apply()
                lastMode = "overlay"
                handler.post { removeTrainingOverlay() }
            }
        }
        trainingOverlay = overlay
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try { wm.addView(overlay, params) } catch (_: Exception) { trainingOverlay = null }
    }

    private fun removeTrainingOverlay() {
        val overlay = trainingOverlay ?: return
        trainingOverlay = null
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(overlay) } catch (_: Exception) {}
    }

    private inner class TrainingOverlay(
        private val message: String,
        private val onPicked: (Int, Int) -> Unit
    ) : View(this@AutoPlayerService) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.argb(55, 0, 0, 0))
            paint.color = Color.WHITE
            paint.textSize = 48f
            paint.setShadowLayer(5f, 2f, 2f, Color.BLACK)
            val width = paint.measureText(message)
            canvas.drawText(message, (this.width - width) / 2f, 110f, paint)
            paint.clearShadowLayer()
            paint.color = Color.argb(210, 30, 30, 30)
            canvas.drawRoundRect(this.width / 2f - 185f, 135f, this.width / 2f + 185f, 205f, 22f, 22f, paint)
            paint.color = Color.WHITE
            paint.textSize = 28f
            val hint = "Tik precies op het midden"
            canvas.drawText(hint, (this.width - paint.measureText(hint)) / 2f, 180f, paint)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_UP) {
                onPicked(event.rawX.toInt(), event.rawY.toInt())
                return true
            }
            return true
        }
    }

    private fun averagePatch(bitmap: Bitmap, x: Int, y: Int): Rgb {
        val radius = (bitmap.width * 0.008f).toInt().coerceIn(4, 14)
        var r = 0L; var g = 0L; var b = 0L; var count = 0
        for (py in (y - radius).coerceAtLeast(0)..(y + radius).coerceAtMost(bitmap.height - 1) step 2) {
            for (px in (x - radius).coerceAtLeast(0)..(x + radius).coerceAtMost(bitmap.width - 1) step 2) {
                val c = bitmap.getPixel(px, py)
                r += Color.red(c); g += Color.green(c); b += Color.blue(c); count++
            }
        }
        return if (count == 0) Rgb(0, 0, 0) else Rgb((r / count).toInt(), (g / count).toInt(), (b / count).toInt())
    }

    private fun readSamples(key: String): List<Rgb> {
        val raw = prefs.getString(key, "") ?: ""
        return raw.split(';').mapNotNull { entry ->
            val parts = entry.split(',')
            if (parts.size != 3) null else try { Rgb(parts[0].toInt(), parts[1].toInt(), parts[2].toInt()) } catch (_: Exception) { null }
        }
    }

    private fun colorSimilarity(color: Rgb, samples: List<Rgb>): Float {
        if (samples.isEmpty()) return 0f
        val nearest = samples.minOf { sample ->
            sqrt(((color.r - sample.r) * (color.r - sample.r) +
                (color.g - sample.g) * (color.g - sample.g) +
                (color.b - sample.b) * (color.b - sample.b)).toFloat())
        }
        return (1f - nearest / 300f).coerceIn(0f, 1f)
    }

    private fun analyze(bitmap: Bitmap) {
        // Keep a fresh frame for one-tap training. Only the most recent frame is retained.
        val trainingCopy = if (trainingOverlay == null) {
            try { bitmap.copy(Bitmap.Config.ARGB_8888, false) } catch (_: Exception) { null }
        } else null
        if (trainingCopy != null) {
            latestFrame?.recycle()
            latestFrame = trainingCopy
        }
        if (prefs.getString("mode", "paused") != "auto") return

        val w = bitmap.width
        val h = bitmap.height
        if (w < 300 || h < 700) return

        val ballSamples = readSamples("ball_samples")
        val backgroundSamples = readSamples("background_samples")
        val step = 4
        val x0 = (w * 0.10f).toInt()
        val x1 = (w * 0.90f).toInt()
        val y0 = (h * 0.40f).toInt()
        val y1 = (h * 0.76f).toInt()
        val cols = ((x1 - x0) + step - 1) / step
        val rows = ((y1 - y0) + step - 1) / step
        val stride = cols + 1
        val red = IntArray((cols + 1) * (rows + 1))
        val green = IntArray((cols + 1) * (rows + 1))
        val blue = IntArray((cols + 1) * (rows + 1))
        for (gy in 0 until rows) {
            var rowR = 0; var rowG = 0; var rowB = 0
            val py = (y0 + gy * step).coerceAtMost(h - 1)
            for (gx in 0 until cols) {
                val px = (x0 + gx * step).coerceAtMost(w - 1)
                val c = bitmap.getPixel(px, py)
                rowR += Color.red(c); rowG += Color.green(c); rowB += Color.blue(c)
                val at = (gy + 1) * stride + gx + 1
                val above = gy * stride + gx + 1
                red[at] = red[above] + rowR
                green[at] = green[above] + rowG
                blue[at] = blue[above] + rowB
            }
        }
        fun sum(table: IntArray, left: Int, top: Int, right: Int, bottom: Int): Int {
            val l = left.coerceIn(0, cols); val t = top.coerceIn(0, rows)
            val r = right.coerceIn(0, cols); val b = bottom.coerceIn(0, rows)
            if (r <= l || b <= t) return 0
            return table[b * stride + r] - table[t * stride + r] - table[b * stride + l] + table[t * stride + l]
        }
        val inner = (w * 0.045f / step).toInt().coerceAtLeast(8)
        val outer = (w * 0.085f / step).toInt().coerceAtLeast(inner + 4)
        var bestScore = Float.NEGATIVE_INFINITY
        var bestX = Float.NaN; var bestY = Float.NaN
        val gxStart = ((w * 0.16f - x0) / step).toInt().coerceAtLeast(outer)
        val gxEnd = ((w * 0.86f - x0) / step).toInt().coerceAtMost(cols - outer)
        val gyStart = ((h * 0.43f - y0) / step).toInt().coerceAtLeast(outer)
        val gyEnd = ((h * 0.74f - y0) / step).toInt().coerceAtMost(rows - outer)
        var gy = gyStart
        while (gy <= gyEnd) {
            var gx = gxStart
            while (gx <= gxEnd) {
                val il = gx - inner; val it = gy - inner; val ir = gx + inner + 1; val ib = gy + inner + 1
                val ol = gx - outer; val ot = gy - outer; val oright = gx + outer + 1; val ob = gy + outer + 1
                val innerArea = ((ir - il) * (ib - it)).toFloat()
                val outerArea = ((oright - ol) * (ob - ot)).toFloat()
                val ringArea = outerArea - innerArea
                if (ringArea > 0f) {
                    val sumR = sum(red, il, it, ir, ib); val sumG = sum(green, il, it, ir, ib); val sumB = sum(blue, il, it, ir, ib)
                    val center = Rgb((sumR / innerArea).toInt(), (sumG / innerArea).toInt(), (sumB / innerArea).toInt())
                    val ringR = (sum(red, ol, ot, oright, ob) - sumR) / ringArea
                    val ringG = (sum(green, ol, ot, oright, ob) - sumG) / ringArea
                    val ringB = (sum(blue, ol, ot, oright, ob) - sumB) / ringArea
                    val dr = center.r - ringR; val dg = center.g - ringG; val db = center.b - ringB
                    val contrast = sqrt(dr * dr + dg * dg + db * db)
                    val positive = colorSimilarity(center, ballSamples)
                    val negative = colorSimilarity(center, backgroundSamples)
                    // Without samples use contrast. With samples, learned ball colour
                    // boosts candidates and learned background colours suppress them.
                    val score = if (ballSamples.isEmpty()) contrast else contrast * 0.50f + positive * 85f - negative * 55f
                    if (contrast > 10f && score > bestScore) {
                        bestScore = score; bestX = x0 + gx * step.toFloat(); bestY = y0 + gy * step.toFloat()
                    }
                }
                gx += 2
            }
            gy += 2
        }
        val minimumScore = if (ballSamples.isEmpty()) 24f else 28f
        if (bestX.isNaN() || bestScore < minimumScore) {
            lostFrames++
            if (lostFrames >= 4) resetTracking()
            return
        }
        lostFrames = 0
        val now = System.currentTimeMillis()
        if (!lastCandidateX.isNaN()) {
            val moved = abs(bestX - lastCandidateX)
            val movedY = abs(bestY - lastCandidateY)
            if (moved > w * 0.10f || movedY > h * 0.08f) {
                stableFrames = 0
                if (tappedThisBall && (moved > w * 0.14f || movedY > h * 0.10f)) tappedThisBall = false
            }
        }
        if (tappedThisBall) {
            lastCandidateX = bestX; lastCandidateY = bestY
            return
        }
        stableFrames++
        lastCandidateX = bestX; lastCandidateY = bestY
        val stackLaneX = w * 0.55f
        val aligned = abs(bestX - stackLaneX) <= w * 0.09f
        if (stableFrames >= 4 && aligned && now - lastTap > 650L) {
            tap(bestX, bestY)
            lastTap = now
            tappedThisBall = true
        }
    }

    private fun resetTracking() {
        stableFrames = 0; tappedThisBall = false
        lastCandidateX = Float.NaN; lastCandidateY = Float.NaN
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0L, 55L)).build()
        dispatchGesture(gesture, null, null)
    }
}
