plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "nl.wachccc.bollenstapelen"
    compileSdk = 35
    defaultConfig {
        applicationId = "nl.wachccc.bollenstapelen"
        minSdk = 30
        targetSdk = 35
        versionCode = 6
        versionName = "0.6-learning"
    }
}
